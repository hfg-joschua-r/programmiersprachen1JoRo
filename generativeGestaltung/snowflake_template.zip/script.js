// JQuery Helper - runs when everything is fully loaded
$(document).ready(() => {

    // Let's make a snowflake out ouf one Y character
    // Change the character for different snowflakes (symmetric ones work best)
    makeASnowFlake("Y").appendTo("#drawing_canvas")

});


function makeASnowFlake(char, single = true) {
    // Make a snowflake div container for one flake
    const flake = $("<div class='snowflake'>"+char+"</div>")

    // If we are only going to make one flake, make it big (by adding a class)!
    if(single) flake.addClass("single")
    
    // TODO: Make a div container for one "arm" of our snowflake, including an "arm" class
    
    // TODO: Append our character multiple times to the arm, scaled and with position offset
    // Parameters:
    // * How many characters? (= how often to loop)
    // * What scale? => via CSS transform / scale
    // * What position offset?  => via CSS margin-bottom
    const numberOfChars = 5;
    const scaleFactor = 2;
    const offsetFactor = 1.5;

    // TODO: After we have one arm, put many of them in the flake container, each rotated by some degrees 
    // (Actual snow flakes have 6 arms ;))
    const numberOfArms = 6;
    

    //We might need that snowflake later, so return it
    return flake;
}